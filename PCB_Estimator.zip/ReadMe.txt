Companion program for the article,

Estimating PCB Design and Complexity
published on PCBDESIGN007, on March 2, 2011

http://design.iconnect007.media/index.php/article/57806/estimating-pcb-design-time-and-complexity

or,

https://web.archive.org/web/20221117011816/http://design.iconnect007.media/index.php/article/57806/estimating-pcb-design-time-and-complexity

Written By: Steven C. Hageman


Program notes,

PCB Estimator is a .NET 3.5 compliant program.

No install is needed. The program can run from any location (i.e. the Desktop).

If .NET 3.5 is not on your PC
the program will reach Microsoft and attempt to install
.NET 3.5 on your computer. This is all handled internally
by the .NET Common Language Runtime.

Any computer that will run .NET 3.5 compliant programs will run PCB Estimator.exe.
See Microsoft.com for exact system requirements.

I PROVIDE THIS FREE SOFTWARE "AS IS". 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO 
ANY WARRANTY OF NON-INFRINGEMENT, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY, SATISFACTORY QUALITY, REASONABLE CARE AND SKILL, 
AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY DISCLAIMED.

Sample input files are in the folder "Samples".


January 29, 2011

